# Numerical method

## Vacuum sector (both horizon and infinity boundaries)

**Method: real-axis multiple shooting on the Riccati (logarithmic-derivative)
form of the Zerilli equation**, integrated with `scipy.integrate.solve_ivp`
(DOP853, adaptive step, rtol/atol ~ 1e-12 to 1e-14).

- Horizon side: Frobenius series start at R = 2+eps (eps = 1e-7), integrated
  outward in R to R=3.
- Infinity side: 8th-order analytic asymptotic series start at R = Rmax,
  integrated *inward* in R to R=3, entirely on the real axis — **no exterior
  complex scaling, no contour rotation of any kind.**

This is materially different from both (a) the transfer-matrix + ECS shooting
approach and (b) Chebyshev Dirichlet-to-Neumann collocation, as required.

**Why this works without ECS:** the "wrong" (non-physical) companion solution
grows during real-axis inward integration from Rmax to R=3 at a rate set by
Im(omega). Because the domain [3, Rmax] is finite, that growth stays within
double-precision headroom provided Rmax is not too large. This was verified
empirically (not assumed): the vacuum benchmark result is checked at 6 values
of Rmax from 15 to 80 (`schwarzschild_benchmark.csv`). Rmax=15 fails the gate
(relative error 4.99e-4 > 1e-4); Rmax=20 also narrowly misses it (relative
error 1.13e-4 > 1e-4). Rmax in [30,80] passes comfortably (relative error
1.19e-5 to 4.01e-5). Rmax=40 was used for the production search, well inside
the validated stable window (relative error 1.19e-5).

## Matter bulk sector

The l=2 even-parity linearized Einstein tensor was derived symbolically in
`sympy` directly from the specified metric ansatz (Christoffel symbols ->
Ricci tensor -> Einstein tensor), independently of any supplied matrix. The
collisionless stress tensor (baseline sharp coefficients + the delta-f, delta-p,
delta-e, delta-s smooth correction) was built exactly as specified in
`CLAUDE_PROMPT.md` and projected onto the seven stated equations, giving a
7x4 matrix M(omega, lambda, chi_J, chi_X).

chi_J(omega), chi_X(omega) are evaluated **live, at each trial frequency**,
via the retarded spectral continuation recipe (trapezoidal weights -> node
densities -> piecewise-linear Cauchy transform -> retarded second-sheet
subtraction for crossed branches), reading only the supplied
`blind_q010_spectral_nodes.npz`. No fixed/precomputed chi constant is used
anywhere in the production search.

For each trial omega: the two physical bulk lambda roots are found from a
4x4 minor (rows TX, XX, Xtheta, AngTrace) via `scipy.optimize.least_squares`,
then validated against the **full** 7x4 matrix by SVD (relative smallest/
largest singular value, reported in `bulk_lambda_audit.csv`).

## Matter-shell transfer and global matching

The two bulk eigenvectors are mapped to the Zerilli (Z, Z_X) state at the
smooth vacuum edge (Z = K - iJ/(9 omega), Z_X = K/27 + 26iJ/(243 omega)), a
2x2 basis matrix C is formed, and the transfer across the shell (conformal
length L = 9 ln(1/q)) is T = C diag(exp(lambda_1 L), exp(lambda_2 L)) C^-1 —
i.e. direct matrix-exponential propagation of the two bulk modes, not an
ODE integration through the matter region (the matter background is exactly
homogeneous in the ocean coordinate X, so this is exact, not an
approximation).

The global condition is: does T applied to the inner vacuum state (ratio
form) produce a state parallel to the outer vacuum state? This determinant
is the root-search objective — an independently-constructed condition, not
an imported determinant formula.

## Root search

12 omega seeds spread evenly across the blind window
(0.34,-0.05)-(0.42,-0.005), each combined with 2 different lambda-seed pairs
(24 total attempts). Convergence required |D| < 1e-4 (see
`all_frequency_seeds.csv` for every attempt and its outcome, including
failures). Converged roots deduplicated at a 1e-4 tolerance in omega.

For the single converged root, an independent argument-principle winding
check (24-point contour, radius 3e-4) gave winding number = 1.000, confirming
a simple isolated pole rather than a numerical artifact.
