# Blind independent QNM verification — output package

This package contains a from-scratch, blind numerical verification of the
matter-led polar QNM problem specified in `CLAUDE_PROMPT.md`. No target
frequency, production solver, or manuscript was used or consulted. No web
search was performed.

## Files

- `independent_solver.py`, `bulk_blind.py`, `spectral.py` — complete source
  for the physics/numerics (vacuum shooting, bulk matrix, spectral
  continuation).
- `run_blind_search.py` — driver script that performs the blind seed grid
  search and writes `all_frequency_seeds.csv`, `all_converged_roots.csv`,
  `resolution_convergence.csv`.
- `winding_audit.py` — driver script for the 24-point argument-principle
  winding-number audit around the converged root; writes
  `winding_audit.csv` and `winding_audit_result.txt`.
- `schwarzschild_benchmark.csv` — vacuum gate check (required before touching
  the matter problem).
- `all_frequency_seeds.csv` — every seed tried (12 omega seeds × 2 lambda
  seed pairs = 24 attempts), with outcome.
- `all_converged_roots.csv` — the deduplicated converged root(s) found inside
  the blind search window.
- `resolution_convergence.csv` — the converged root re-evaluated at three
  outer-vacuum resolutions (Rmax = 25, 40, 60).
- `bulk_lambda_audit.csv` — the two physical bulk radial exponents at the
  converged root, with full-7x4 SVD relative residuals.
- `winding_audit.csv` — raw 24-point contour data (omega, D(omega)) for the
  winding-number audit.
- `winding_audit_result.txt` — winding-number audit summary (result: 1.000000).
- `numerical_method.md` — method description and independence statement.
- `final_verdict.txt` — the required seven-question summary.

## Reproducing

```
pip install numpy scipy sympy
python3 run_blind_search.py     # produces the root-search CSVs
python3 winding_audit.py        # produces the winding-number audit
```

Requires `blind_q010_spectral_nodes.npz` in the same directory. Both scripts
were run once to produce the results in this package; results are otherwise
unchanged from the original submission.
